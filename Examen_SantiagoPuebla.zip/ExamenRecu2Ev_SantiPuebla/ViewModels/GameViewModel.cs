﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Wpf.Ui;

namespace ExamenRecu2Ev_SantiPuebla.ViewModels
{
    public partial class GameViewModel : ViewModel
    {
        private readonly HttpClient _httpClient;
        private readonly INavigationService _navigationService;


        public GameViewModel(HttpClient httpClient, INavigationService navigationService)
        {
            _httpClient = httpClient;
            _navigationService = navigationService;
        }

        [RelayCommand]
        public void GameInit()
        {

        }
    }
}
