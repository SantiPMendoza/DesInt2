﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ExamenRecu2Ev_SantiPuebla.Views.Pages
{
    /// <summary>
    /// Lógica de interacción para GamePage.xaml
    /// </summary>
    public partial class GamePage : INavigableView<GameViewModel>
    {
        public GameViewModel ViewModel { get; }
        public GamePage(GameViewModel viewModel)
        {
            ViewModel = viewModel;
            DataContext = this;

            InitializeComponent();
            GenerateGame();
        }

        public void GenerateGame()
        {
            for (int i = 0; i < 25; i++)
            {
                Button b = new Button();
                b.Background = new SolidColorBrush(Colors.Green);
                AddLogicalChild(b);
            }
        }
    }
}
