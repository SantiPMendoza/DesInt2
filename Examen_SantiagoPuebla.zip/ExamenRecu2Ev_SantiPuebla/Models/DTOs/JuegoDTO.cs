﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ExamenRecu2Ev_SantiPuebla.Models.DTOs
{
    public class JuegoDTO
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("fecha_inicio")]
        public DateTime Fecha_Inicio { get; set; }


        [JsonPropertyName("fecha_fin")]
        public DateTime Fecha_Fin { get; set; }


    }
}
