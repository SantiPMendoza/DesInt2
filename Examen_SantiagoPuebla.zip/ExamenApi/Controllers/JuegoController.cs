﻿using AutoMapper;
using ExamenApi.Models;
using ExamenApi.Models.DTOs.JuegoDTO;
using ExamenApi.Repository.IRepository;
using Microsoft.AspNetCore.Mvc;

namespace ExamenApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JuegoController : BaseController<Juego, JuegoDTO, CreateJuegoDTO>
    {
        public JuegoController(IJuegoRepository juegoRepository, IMapper mapper, ILogger<JuegoController> logger)
            : base(juegoRepository, mapper, logger)
        {


        }
    }
}
