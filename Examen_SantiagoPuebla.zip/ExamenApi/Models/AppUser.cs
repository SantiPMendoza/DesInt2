﻿using Microsoft.AspNetCore.Identity;

namespace ExamenApi.Models
{
    public class AppUser : IdentityUser
    {

        public string Name { get; set; }


        public string Email { get; set; }

    }
}
