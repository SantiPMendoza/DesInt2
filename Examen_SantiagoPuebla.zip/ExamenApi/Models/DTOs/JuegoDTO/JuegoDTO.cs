﻿namespace ExamenApi.Models.DTOs.JuegoDTO
{
    public class JuegoDTO : CreateJuegoDTO
    {
        public int Id { get; set; }

    }
}
