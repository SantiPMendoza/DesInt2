﻿using System.ComponentModel.DataAnnotations;

namespace ExamenApi.Models.DTOs.JuegoDTO
{
    public class CreateJuegoDTO
    {
        [Required(ErrorMessage = "Field required: Nombre")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Field required: UserName")]
        public string UserId { get; set; }
        public DateTime Fecha_Inicio { get; set; }
        public DateTime Fecha_Fin { get; set; }
    }
}
